import os

DATAPATH = os.path.abspath(os.path.dirname(__file__))
